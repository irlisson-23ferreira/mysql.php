<?php
 session_start();
 if(isset($_SESSION['id'])==0 and isset($_SESSION['nome'])==0){
  echo "<script> window.location='login.php'</script>";
}else{
  $id_funcionario=$_SESSION['id'];
  $nome=$_SESSION['nome'];
    
  echo "<h3>Usuário: $nome $id_funcionario / <a href='login.php'>sair</a></h3>";
}
?>
<HTML>
  <HEAD>
    <meta charset="utf-8">
     <TITLE>Cadastros</TITLE>
 <style type="text/css">
 
 tbody tr:hover{background-color:#555}  
  

 </style>
 <script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
   $('#tab tbody tr:odd').addClass('zebraUm');
   $('#tab tbody tr:even').addClass('zebraDois');
});
</script>




 <script type="text/javascript">
   function valida_form (){
    if(document.getElementById("produto").value.length < 1){
      alert('Por favor, preencha');
      document.getElementById('produto').focus();
      return false
    }
   }
 </script>

 <script type="text/javascript">
   function valida_form2 (){
    if(document.getElementById("preco").value.length < 1){
      alert('Por favor, preencha');
      document.getElementById('preco').focus();
      return false
    }
   }
 </script>
 <script type="text/javascript" src="jquery-3.2.1.js"></script>
 <script src="jquery.maskMoney.js" type="text/javascript"></script>
<script type="text/javascript">
  $(document).ready(function(){

    $(function(){
        $("#valor").maskMoney({symbol:'R$ ',showSymbol:true, thousands:'.', decimal:',', symbolStay: true
      });
</script>
</HEAD>
<BODY> 
<center> 
  <fieldset>
  <div id="quadrado2">

    <h1>Cadastro de Produtos</h1>
</div>
 <br>

  <center>
  
  <form action ="evento.php?cadastro=true" method = "post" onsubmit="return valida_form(this)">

  <label>Produto:</label>
  <input type="text" label for="produto" value='' name='produto' required >

<p></p>
  <label>Preço:</label>
   <input type="text" id="valor" placeholder="R$" name="preco" required onfocus ="valida_form(this)">
</center>
 <BR>
 <input type="submit" value="cadastrar">
 </form>
 </fieldset>


 <BR>
 <BR>
 <style>
   
 </style>

 <table id="tab" border="" width="430px">
 <thead>
<tr>
  <th>ID</th>
  <th>Produto</th>
  <th>Preço</th>
  <th>Funcionário</th>
  <th>Alterar</th>
  <th>Excluir</th>
</tr>
</thead>
 </style>
<center>
  <?php
            include_once "conexao.php";
            $sql = "select p.codigo, p.nome as np, p.preco, c.nome as nf from funcionario as c join produto as p on
            c.id_funcionario=p.id_funcionario";
            $result = mysql_query($sql,$con);
            if($result){
            while($linha = mysql_fetch_array($result)){
?>

<tbody>
       <tr>
           <td id='p3'> <?php  echo $linha['codigo'];?></td>
           <td> <?php echo $linha['np'];?></td>
           <td id='p4'> <?php echo "R$". $linha['preco'].",00";?></td>
           <td> <?php echo $linha['nf'];?></td>       
           <td> <?php echo "<a id='p1' href = editar.php?editar=".$linha['codigo']." >editar </a>";?></td>
           <td> <?php echo "<a id='p2' href = evento.php?deletar=".$linha['codigo'].">excluir</a>";?></td>
       </tr>
</tbody>
<?php
          }
      
          }
          mysql_close($con);
?>
</table> 

<BR>

</BODY>
</HTML>