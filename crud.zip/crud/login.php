<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	
</head>
<body>
	


</style>
	<center>
<div id="quadrado">
	<h1>Sistema Controle de Produtos</h1>
</div>

<fieldset>
<form method="post" action="">
	Login <br>
	<input type="text" class="caixa1" name="login" required><br><br>
	Senha <br>
	<input type="password" name="senha" required><br><br>
 	<input type="submit" value="Entrar">
 	
</form>
</fieldset>
</center>
<?php
include_once "conexao.php";
if(isset($_POST['login']))$login = $_POST['login'];
if(isset($_POST['senha']))$senha = $_POST['senha'];
$sql="select * from funcionario where nome='$login' and senha='$senha'";
$result=mysql_query($sql,$con);
$res=mysql_num_rows($result);
if($res){
	$linha=mysql_fetch_array($result);
	session_start();
	$_SESSION['id']=$linha['id_funcionario'];
	$_SESSION['nome']=$linha['nome'];
	echo "<script> window.location=' index.php'</script>";		
}
?>
</body>
</html>