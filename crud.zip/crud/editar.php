<html>
<head>
	<meta charset="utf-8">
	
</head>
<script type="text/javascript" src="jquery-3.2.1.js"></script>
 <script src="jquery.maskMoney.js" type="text/javascript"></script>
<script type="text/javascript">
  $(document).ready(function(){

    $(function(){
        $("#valor").maskMoney({symbol:'R$ ',showSymbol:true});
    })});
</script>
<body>

	<?php
	include_once 'conexao.php';
	$sql='select * from produto where codigo='.$_GET['editar'];
	$result=mysql_query($sql,$con);
	$linha=mysql_fetch_array($result);
	?>  
	<center>
	<fieldset>
	<table>
 <div id="quadrado3">

	<h3> Editar Contato </h3>
</div>

	<?php echo "<form action= 'evento.php?editar=".$linha['codigo']."'method='post'>";?>
		Produto: <input type="text" name="produto" value="<?php echo $linha['nome'];?>"><p></p>
		Preço: <input type="text" name="preco" id="valor" value="<?php echo $linha['preco'];?>"><p></p>
		<input type="submit" value="Editar">
	</form> 
</table>
</fieldset>
</center>
</body>
</html>